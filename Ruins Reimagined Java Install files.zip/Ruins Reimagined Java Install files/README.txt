Instructions to install Ruins Reimagined: Corfe Castle

Step 1: Copy the "Ruins Reimagined Corfe Castle" folder
Step 2: Paste it to the following directory:

Windows:  C:\Users\(your_username)\AppData\Roaming\.minecraft\saves\

Macintosh: /Users/(your_username)/Library/Application Support/minecraft/saves/

Linux: /home/.minecraft/saves/ 

Or check out the server: 

corfe.ruinsreimagined.com