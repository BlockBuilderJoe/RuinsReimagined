Instructions to install Ruins Reimagined: Corfe Castle

Step 1: Copy the "Ruins Reimagined Corfe Castle"
Step 2: Paste it to the following directory

Windows:  C:\Users\(your_username)\AppData\Roaming\.minecraft\saves\
Mac: /Users/(your_username)/Library/Application Support/minecraft/saves/
Linux: /home/.minecraft/saves/ 

OR: check out the server: corfe.ruinsreimagined.com